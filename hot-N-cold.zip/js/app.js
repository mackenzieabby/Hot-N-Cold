$(document).ready(function(){
	// Global Variables.
    var theSecret = Math.floor((Math.random() * 100) + 0); // Secret
    var theGuess = $('#userGuess').val(); //Guess
	/*--- Display information modal box ---*/
  	$(".what").click(function(){
    	$(".overlay").fadeIn(1000);

  	});

  	/*--- Hide information modal box ---*/
  	$("a.close").click(function(){
  		$(".overlay").fadeOut(1000);
  	});



   function test() {
   	$('#guessButton').click(function(event) {
   		if(theGuess == theSecret) {
   			return theGuess;
   	alert("You Got It")
   }
   else
   	alert('You didnt');
   console.log(theSecret);
   	});
   }

   
});


